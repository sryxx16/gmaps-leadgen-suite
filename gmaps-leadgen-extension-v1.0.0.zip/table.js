// table.js
// GMaps Lead Finder - Table Controller with Contact Status Tracking & Free Gemini AI

const tbody = document.getElementById('tbody');
const summary = document.getElementById('summary');
const emptyState = document.getElementById('emptyState');
const searchInput = document.getElementById('search');
const onlyNoWebsite = document.getElementById('onlyNoWebsite');
const statusFilter = document.getElementById('statusFilter');
const aiWebFilter = document.getElementById('aiWebFilter');

const exportCsvBtn = document.getElementById('exportCsvBtn');
const exportJsonBtn = document.getElementById('exportJsonBtn');
const syncDashboardBtn = document.getElementById('syncDashboardBtn');
const syncStatus = document.getElementById('syncStatus');
const clearBtn = document.getElementById('clearBtn');
const addManualBtn = document.getElementById('addManualBtn');
const manualForm = document.getElementById('manualForm');

// AI & API Key elements
const aiBatchBtn = document.getElementById('aiBatchBtn');
const apiKeyBtn = document.getElementById('apiKeyBtn');
const apiKeyModal = document.getElementById('apiKeyModal');
const closeApiKeyModal = document.getElementById('closeApiKeyModal');
const geminiApiKeyInput = document.getElementById('geminiApiKeyInput');
const saveApiKeyBtn = document.getElementById('saveApiKeyBtn');

const aiPitchModal = document.getElementById('aiPitchModal');
const closeAiModal = document.getElementById('closeAiModal');
const modalBizName = document.getElementById('modalBizName');
const modalScoreWrap = document.getElementById('modalScoreWrap');
const modalReason = document.getElementById('modalReason');
const modalPitchText = document.getElementById('modalPitchText');
const copyPitchBtn = document.getElementById('copyPitchBtn');
const openWaWithPitchBtn = document.getElementById('openWaWithPitchBtn');

// Manual form elements
const mName = document.getElementById('mName');
const mCategory = document.getElementById('mCategory');
const mRating = document.getElementById('mRating');
const mReviews = document.getElementById('mReviews');
const mAddress = document.getElementById('mAddress');
const mPhone = document.getElementById('mPhone');
const mWebsite = document.getElementById('mWebsite');
const mMapsUrl = document.getElementById('mMapsUrl');
const mSaveBtn = document.getElementById('mSaveBtn');
const mCancelBtn = document.getElementById('mCancelBtn');

let allLeads = [];
let currentFilteredLeads = [];
let activeModalLead = null;

// Normalisasi nomor telepon lokal Indonesia ke format wa.me (628...)
function normalizePhoneForWa(phone) {
  if (!phone) return '';
  let digits = phone.replace(/[^\d]/g, '');
  if (digits.startsWith('0')) digits = '62' + digits.slice(1);
  if (!digits.startsWith('62') && digits.length >= 8) digits = '62' + digits;
  return digits;
}

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// Render tabel utama
function render() {
  const query = searchInput.value.trim().toLowerCase();
  const filterNoSite = onlyNoWebsite.checked;
  const filterStatusVal = statusFilter.value;
  const filterAiWebVal = aiWebFilter ? aiWebFilter.value : 'ALL';

  currentFilteredLeads = allLeads.filter((l) => {
    if (filterNoSite && l.hasWebsite) return false;
    
    // Filter status prospek (belum/dihubungi/tertarik/ditolak)
    const leadStatus = l.status || 'belum';
    if (filterStatusVal !== 'ALL' && leadStatus !== filterStatusVal) return false;

    // Filter verifikasi website AI (NO_WEBSITE / SOSMED_MARKETPLACE / REAL_WEBSITE)
    if (filterAiWebVal !== 'ALL') {
      const aiStatus = l.aiAnalysis?.webStatus;
      if (filterAiWebVal === 'NO_WEBSITE' && aiStatus !== 'NO_WEBSITE') return false;
      if (filterAiWebVal === 'SOSMED_MARKETPLACE' && aiStatus !== 'SOSMED_MARKETPLACE') return false;
      if (filterAiWebVal === 'REAL_WEBSITE' && aiStatus !== 'REAL_WEBSITE') return false;
    }

    if (!query) return true;
    return (
      (l.name || '').toLowerCase().includes(query) ||
      (l.address || '').toLowerCase().includes(query) ||
      (l.category || '').toLowerCase().includes(query) ||
      (l.phone || '').toLowerCase().includes(query)
    );
  });

  summary.textContent = `${currentFilteredLeads.length} data ditampilkan (dari ${allLeads.length} total tersimpan)`;

  tbody.innerHTML = '';
  emptyState.hidden = currentFilteredLeads.length > 0;

  for (let i = 0; i < currentFilteredLeads.length; i++) {
    const lead = currentFilteredLeads[i];
    const tr = document.createElement('tr');

    // Kolom Website dengan Verifikasi Cerdas AI
    let websiteCell = '';
    if (lead.aiAnalysis?.webStatus === 'NO_WEBSITE') {
      websiteCell = `<span class="badge no" title="Diverifikasi AI: Benar-benar tidak punya website">🚫 Tanpa Web</span>`;
    } else if (lead.aiAnalysis?.webStatus === 'SOSMED_MARKETPLACE') {
      const link = lead.website ? `<a class="site-link" href="${escapeHtml(lead.website)}" target="_blank" style="font-size:11.5px;display:block;margin-top:2px;">${escapeHtml(lead.website)}</a>` : '';
      websiteCell = `<span class="badge" style="background:#fef3c7;color:#b45309;border:1px solid #fcd34d;" title="Diverifikasi AI: Cuma punya link Shopee/Tokped/Sosmed (Target Empuk!)">🛍️ Cuma Sosmed</span>${link}`;
    } else if (lead.aiAnalysis?.webStatus === 'REAL_WEBSITE') {
      websiteCell = `<span class="badge yes" title="Diverifikasi AI: Sudah punya website resmi mandiri">✅ Web Resmi</span> <a class="site-link" href="${escapeHtml(lead.website)}" target="_blank" style="display:block;font-size:11.5px;margin-top:2px;">${escapeHtml(lead.website)}</a>`;
    } else {
      websiteCell = lead.hasWebsite
        ? `<a class="site-link" href="${escapeHtml(lead.website)}" target="_blank" rel="noopener">${escapeHtml(lead.website)}</a>`
        : `<span class="badge no">Belum ada</span>`;
    }

    const waNumber = normalizePhoneForWa(lead.phone);
    const mapsLink = lead.mapsUrl
      ? `<a class="maps-link" href="${escapeHtml(lead.mapsUrl)}" target="_blank" rel="noopener">Buka Maps</a>`
      : `<span class="disabled">Maps</span>`;

    const ratingDisplay = lead.rating 
      ? `<span style="color:#d97706;font-weight:600;">★ ${escapeHtml(lead.rating)}</span> <span style="color:#64748b;font-size:11.5px;">(${escapeHtml(lead.reviewCount || '0')})</span>`
      : `<span style="color:#94a3b8;">-</span>`;

    // AI Score Badge jika sudah dianalisa
    let aiScoreBadge = '';
    if (lead.aiAnalysis && lead.aiAnalysis.score) {
      const sc = lead.aiAnalysis.score.toUpperCase();
      if (sc === 'HOT') aiScoreBadge = `<div class="ai-badge hot">🔥 HOT LEAD</div>`;
      else if (sc === 'WARM') aiScoreBadge = `<div class="ai-badge warm">⚡ WARM LEAD</div>`;
      else aiScoreBadge = `<div class="ai-badge cold">❄️ COLD LEAD</div>`;
    }

    // Status Prospek Dropdown
    const curStatus = lead.status || 'belum';
    const statusSelectHtml = `
      <select class="status-select ${curStatus}" data-lead-index="${i}">
        <option value="belum" ${curStatus === 'belum' ? 'selected' : ''}>⏳ Belum Dihubungi</option>
        <option value="dihubungi" ${curStatus === 'dihubungi' ? 'selected' : ''}>📞 Sudah Dihubungi</option>
        <option value="tertarik" ${curStatus === 'tertarik' ? 'selected' : ''}>🤝 Tertarik / Deal</option>
        <option value="ditolak" ${curStatus === 'ditolak' ? 'selected' : ''}>❌ Ditolak / Batal</option>
      </select>
    `;

    // Tombol WA & AI Pitch
    const waButton = waNumber
      ? `<button class="btn-wa" data-action="wa" data-lead-index="${i}">Chat WA</button>`
      : `<span class="disabled">No WA</span>`;

    const aiButton = `<button class="btn-ai-single" data-action="ai" data-lead-index="${i}">✨ AI Pitch</button>`;

    tr.innerHTML = `
      <td class="name-cell">
        <div>${escapeHtml(lead.name)}</div>
        ${aiScoreBadge}
      </td>
      <td>${ratingDisplay}</td>
      <td class="muted-cell">${escapeHtml(lead.category || '-')}</td>
      <td class="muted-cell" style="max-width:220px;word-break:break-word;">${escapeHtml(lead.address || '-')}</td>
      <td class="muted-cell" style="white-space:nowrap;">${escapeHtml(lead.phone || '-')}</td>
      <td>${websiteCell}</td>
      <td>${statusSelectHtml}</td>
      <td>
        <div class="action-links">
          ${waButton}
          ${aiButton}
          ${mapsLink}
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  }

  attachRowEventListeners();
}

// Pasang event listener untuk dropdown status & tombol aksi di setiap baris
function attachRowEventListeners() {
  // Dropdown perubahan status prospek
  const selects = tbody.querySelectorAll('.status-select');
  selects.forEach((sel) => {
    sel.addEventListener('change', async (e) => {
      const idx = parseInt(e.target.getAttribute('data-lead-index'), 10);
      const newStatus = e.target.value;
      const lead = currentFilteredLeads[idx];
      if (lead) {
        lead.status = newStatus;
        if (newStatus === 'dihubungi') lead.contactedAt = new Date().toISOString();
        await saveAllLeadsToStorage();
        e.target.className = `status-select ${newStatus}`;
      }
    });
  });

  // Tombol aksi baris (WA & AI Pitch)
  const buttons = tbody.querySelectorAll('button[data-action]');
  buttons.forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      const action = btn.getAttribute('data-action');
      const idx = parseInt(btn.getAttribute('data-lead-index'), 10);
      const lead = currentFilteredLeads[idx];
      if (!lead) return;

      if (action === 'wa') {
        await handleOpenWhatsApp(lead);
      } else if (action === 'ai') {
        await handleOpenAiPitch(lead);
      }
    });
  });
}

// Buka WhatsApp dan otomatis tandai status sebagai "Sudah Dihubungi"
async function handleOpenWhatsApp(lead) {
  const waNumber = normalizePhoneForWa(lead.phone);
  if (!waNumber) {
    alert('Nomor telepon tidak valid.');
    return;
  }

  // Tandai otomatis sebagai "Sudah Dihubungi"
  lead.status = 'dihubungi';
  lead.contactedAt = new Date().toISOString();
  await saveAllLeadsToStorage();
  render();

  // Pesan default atau pesan hasil analisis AI
  let text = '';
  if (lead.aiAnalysis && lead.aiAnalysis.pitch) {
    text = lead.aiAnalysis.pitch;
  } else {
    text = `Halo kak admin ${lead.name}, salam kenal! Saya lihat bisnis kakak di Google Maps sudah sangat bagus ulasannya. Kami mau menawarkan pembuatan website katalog resmi untuk ${lead.name} agar pelanggan bisa pesan langsung dengan mudah.`;
  }

  const url = `https://wa.me/${waNumber}?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank', 'noopener');
}

// Buka modal AI Pitch untuk lead tertentu
async function handleOpenAiPitch(lead) {
  activeModalLead = lead;
  modalBizName.textContent = `✨ Analisis AI: ${lead.name}`;

  // Jika belum dianalisis, coba lakukan analisis langsung
  if (!lead.aiAnalysis) {
    modalScoreWrap.innerHTML = `<span style="color:#8b5cf6;font-weight:600;">Sedang menganalisis data dengan Gemini AI...</span>`;
    modalReason.textContent = 'Menghubungkan ke Gemini API...';
    modalPitchText.textContent = 'Membuat draft chat penawaran yang dipersonalisasi...';
    aiPitchModal.style.display = 'flex';

    const success = await runAiAnalysisForLead(lead);
    if (!success) {
      modalScoreWrap.innerHTML = `<span style="color:#ef4444;font-weight:600;">Gagal menganalisis</span>`;
      modalReason.textContent = 'Pastikan Gemini API Key sudah diisi di menu "⚙️ API Key Gemini" di atas.';
      modalPitchText.textContent = 'Klik tombol "⚙️ API Key Gemini" di pojok kanan atas untuk memasukkan API Key gratis kamu.';
      return;
    }
  }

  // Tampilkan hasil
  const an = lead.aiAnalysis;
  const scoreClass = (an.score || 'WARM').toLowerCase();
  modalScoreWrap.innerHTML = `
    <span class="ai-badge ${scoreClass}" style="font-size:12px;padding:4px 10px;">
      ${scoreClass === 'hot' ? '🔥 HOT LEAD' : scoreClass === 'warm' ? '⚡ WARM LEAD' : '❄️ COLD LEAD'}
    </span>
  `;
  modalReason.textContent = an.reason || 'Potensi calon klien website.';
  modalPitchText.textContent = an.pitch || '';
  aiPitchModal.style.display = 'flex';
}

const DEFAULT_AI_KEY = 'sk-34bfff0ba1494b3fa81e494b7b2535d1';

// Panggil AI (DeepSeek / Gemini) untuk menganalisis calon klien
async function runAiAnalysisForLead(lead) {
  const { geminiApiKey } = await chrome.storage.local.get('geminiApiKey');
  const apiKey = (geminiApiKey || DEFAULT_AI_KEY).trim();
  if (!apiKey) {
    apiKeyModal.style.display = 'flex';
    return false;
  }

  const prompt = `Kamu adalah AI lead qualification & web consultant expert di Indonesia.
Analisis data bisnis ini:
- Nama Bisnis: "${lead.name}"
- Kategori: "${lead.category || '-'}"
- Rating: ${lead.rating || '0'} (${lead.reviewCount || '0'} ulasan)
- Alamat: "${lead.address || '-'}"
- URL di Google Maps: "${lead.website || 'TIDAK ADA'}"

Tugas analisamu:
1. Tentukan status website bisnis ini secara akurat:
   - "NO_WEBSITE": Sama sekali tidak punya website.
   - "SOSMED_MARKETPLACE": Cuma punya link Shopee/Tokopedia/Instagram/TikTok/Linktree/WhatsApp (Belum punya website sendiri, target sangat empuk untuk jasa pembuatan website!).
   - "REAL_WEBSITE": Sudah punya website resmi mandiri (misal domain .id/.com toko sendiri, seperti topscore.id).

2. Tentukan skor prospek:
   - "HOT": Bisnis ramai/rating tinggi tapi NO_WEBSITE atau SOSMED_MARKETPLACE.
   - "WARM": Bisnis skala menengah yang potensial.
   - "COLD": Ulasan sepi atau sudah punya REAL_WEBSITE mandiri.

3. Tulis alasan singkat 1-2 kalimat (sebutkan secara tegas apakah mereka benar-benar tidak punya web, cuma punya sosmed/marketplace, atau sudah punya web resmi).
4. Buat draft pesan WhatsApp penawaran jasa pembuatan website resmi yang sangat dipersonalisasi. Jika mereka cuma punya Shopee/IG, tawarkan website mandiri agar hemat fee admin marketplace.

Kembalikan HANYA format JSON valid tanpa markdown pembungkus:
{
  "webStatus": "NO_WEBSITE" | "SOSMED_MARKETPLACE" | "REAL_WEBSITE",
  "webStatusLabel": "Benar-benar Tanpa Web" | "Cuma Sosmed/Marketplace" | "Punya Web Resmi",
  "score": "HOT" | "WARM" | "COLD",
  "reason": "Alasan singkat",
  "pitch": "Teks pesan WhatsApp siap kirim lengkap dengan sapaan"
}`;

  try {
    let cleanJson = null;

    // Jika key DeepSeek (dimulai sk-)
    if (apiKey.startsWith('sk-')) {
      const res = await fetch('https://api.deepseek.com/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: 'deepseek-chat',
          messages: [{ role: 'user', content: prompt }],
          response_format: { type: 'json_object' }
        }),
      });

      const data = await res.json();
      const content = data?.choices?.[0]?.message?.content;
      if (!content) throw new Error(data.error?.message || 'Gagal memproses respon DeepSeek');
      cleanJson = JSON.parse(content);
    } else {
      // Jika key Gemini (dimulai AIza...)
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.3,
            responseMimeType: 'application/json'
          }
        })
      });

      const data = await res.json();
      const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!rawText) throw new Error(data.error?.message || 'Format respon Gemini kosong');
      cleanJson = JSON.parse(rawText.replace(/```json/g, '').replace(/```/g, '').trim());
    }

    lead.aiAnalysis = cleanJson;
    await saveAllLeadsToStorage();
    render();
    return true;
  } catch (err) {
    console.error('AI API Error:', err);
    return false;
  }
}

// Analisis semua lead yang belum dianalisa secara massal
async function runBatchAiAnalysis() {
  const { geminiApiKey } = await chrome.storage.local.get('geminiApiKey');
  if (!geminiApiKey) {
    apiKeyModal.style.display = 'flex';
    return;
  }

  const unanalyzed = currentFilteredLeads.filter(l => !l.aiAnalysis);
  if (unanalyzed.length === 0) {
    alert('Semua data yang tampil sudah memiliki analisis AI.');
    return;
  }

  if (!confirm(`Mulai analisis AI untuk ${unanalyzed.length} data bisnis terpilih?`)) return;

  aiBatchBtn.disabled = true;
  let done = 0;

  for (const lead of unanalyzed) {
    aiBatchBtn.textContent = `Memproses (${done + 1}/${unanalyzed.length})...`;
    await runAiAnalysisForLead(lead);
    done++;
    await new Promise(r => setTimeout(r, 1200)); // jeda sopan untuk rate limit free tier
  }

  aiBatchBtn.disabled = false;
  aiBatchBtn.textContent = '✨ Analisa AI Semua';
  alert(`Selesai menganalisis ${done} data bisnis dengan Gemini AI!`);
}

// Simpan seluruh leads ke chrome.storage.local
async function saveAllLeadsToStorage() {
  await chrome.storage.local.set({ leads: allLeads.slice().reverse() });
}

async function loadLeads() {
  const { leads = [] } = await chrome.storage.local.get('leads');
  allLeads = leads.slice().reverse(); // Data terbaru di atas
  render();
}

function toCsvValue(v) {
  const s = String(v ?? '');
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

function exportCsv() {
  if (currentFilteredLeads.length === 0) {
    alert('Tidak ada data yang tampil untuk di-export.');
    return;
  }
  
  const rows = [
    ['Nama Bisnis', 'Skor AI', 'Rating', 'Ulasan', 'Kategori', 'Alamat', 'Telepon', 'Website', 'Status Prospek', 'Draft Pitch WA', 'Maps URL', 'Tanggal Diambil'],
    ...currentFilteredLeads.map((l) => [
      l.name,
      l.aiAnalysis?.score || 'Belum dianalisa',
      l.rating || '',
      l.reviewCount || '',
      l.category || '',
      l.address || '',
      l.phone || '',
      l.website || '',
      l.status || 'belum',
      l.aiAnalysis?.pitch || '',
      l.mapsUrl || '',
      l.scrapedAt,
    ]),
  ];
  const csv = rows.map((r) => r.map(toCsvValue).join(',')).join('\n');
  const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `gmaps-leads-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function exportJson() {
  if (currentFilteredLeads.length === 0) {
    alert('Tidak ada data yang tampil untuk di-export.');
    return;
  }
  const json = JSON.stringify(currentFilteredLeads, null, 2);
  const blob = new Blob([json], { type: 'application/json;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `gmaps-leads-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// 1-Click Sync ke Dashboard Web
async function syncToDashboard() {
  if (currentFilteredLeads.length === 0) {
    alert('Tidak ada data yang tampil untuk dikirim ke Dashboard.');
    return;
  }

  syncStatus.style.display = 'block';
  syncStatus.style.background = '#eff6ff';
  syncStatus.style.color = '#1d4ed8';
  syncStatus.textContent = 'Mengirim data ke Dashboard (http://localhost:3000)...';

  try {
    const res = await fetch('http://localhost:3000/api/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ data: currentFilteredLeads }),
    });

    const result = await res.json();
    if (result.success) {
      syncStatus.style.background = '#ecfdf5';
      syncStatus.style.color = '#047857';
      syncStatus.textContent = `✅ Berhasil kirim ${result.inserted} data baru ke Web Dashboard!`;
    } else {
      syncStatus.style.background = '#fef2f2';
      syncStatus.style.color = '#b91c1c';
      syncStatus.textContent = `❌ Gagal: ${result.error || 'Terjadi kesalahan'}`;
    }
  } catch (err) {
    syncStatus.style.background = '#fef2f2';
    syncStatus.style.color = '#b91c1c';
    syncStatus.textContent = `❌ Gagal menghubungi Dashboard di http://localhost:3000. Pastikan dev server sudah jalan.`;
  }

  setTimeout(() => {
    syncStatus.style.display = 'none';
  }, 6000);
}

// Event Listeners
searchInput.addEventListener('input', render);
onlyNoWebsite.addEventListener('change', render);
statusFilter.addEventListener('change', render);
if (aiWebFilter) aiWebFilter.addEventListener('change', render);

exportCsvBtn.addEventListener('click', exportCsv);
exportJsonBtn.addEventListener('click', exportJson);
syncDashboardBtn.addEventListener('click', syncToDashboard);
aiBatchBtn.addEventListener('click', runBatchAiAnalysis);

// API Key Modal
apiKeyBtn.addEventListener('click', async () => {
  const { geminiApiKey = '' } = await chrome.storage.local.get('geminiApiKey');
  geminiApiKeyInput.value = geminiApiKey || DEFAULT_AI_KEY;
  apiKeyModal.style.display = 'flex';
});

closeApiKeyModal.addEventListener('click', () => {
  apiKeyModal.style.display = 'none';
});

saveApiKeyBtn.addEventListener('click', async () => {
  const key = geminiApiKeyInput.value.trim();
  await chrome.storage.local.set({ geminiApiKey: key });
  apiKeyModal.style.display = 'none';
  alert('API Key AI berhasil disimpan!');
});

// AI Modal Actions
closeAiModal.addEventListener('click', () => {
  aiPitchModal.style.display = 'none';
});

copyPitchBtn.addEventListener('click', () => {
  if (!activeModalLead || !activeModalLead.aiAnalysis?.pitch) return;
  navigator.clipboard.writeText(activeModalLead.aiAnalysis.pitch);
  copyPitchBtn.textContent = '✅ Berhasil Disalin!';
  setTimeout(() => { copyPitchBtn.textContent = '📋 Salin Draft Chat'; }, 2000);
});

openWaWithPitchBtn.addEventListener('click', async () => {
  if (!activeModalLead) return;
  aiPitchModal.style.display = 'none';
  await handleOpenWhatsApp(activeModalLead);
});

clearBtn.addEventListener('click', async () => {
  if (!confirm('Yakin mau menghapus semua data yang sudah tersimpan?')) return;
  await chrome.storage.local.set({ leads: [] });
  loadLeads();
});

addManualBtn.addEventListener('click', () => {
  manualForm.hidden = !manualForm.hidden;
});

mCancelBtn.addEventListener('click', () => {
  manualForm.hidden = true;
  [mName, mCategory, mRating, mReviews, mAddress, mPhone, mWebsite, mMapsUrl].forEach((el) => (el.value = ''));
});

mSaveBtn.addEventListener('click', async () => {
  const name = mName.value.trim();
  if (!name) {
    alert('Nama bisnis wajib diisi.');
    return;
  }
  const website = mWebsite.value.trim();
  const newLead = {
    name,
    category: mCategory.value.trim(),
    rating: mRating.value.trim(),
    reviewCount: mReviews.value.trim(),
    address: mAddress.value.trim(),
    phone: mPhone.value.trim(),
    website,
    hasWebsite: !!website,
    status: 'belum',
    mapsUrl: mMapsUrl.value.trim(),
    scrapedAt: new Date().toISOString(),
  };
  const { leads = [] } = await chrome.storage.local.get('leads');
  leads.push(newLead);
  await chrome.storage.local.set({ leads });

  [mName, mCategory, mRating, mReviews, mAddress, mPhone, mWebsite, mMapsUrl].forEach((el) => (el.value = ''));
  manualForm.hidden = true;
  loadLeads();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.leads) {
    loadLeads();
  }
});

loadLeads();
