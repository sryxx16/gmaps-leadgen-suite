// content.js
// GMaps Lead Finder v1.4.0 - Ultra-Fast, Anti-Duplicate & AI-Integrated Engine
const SCRIPT_VERSION = '1.4.0';

let isRunning = false;
let shouldStop = false;
let processedCount = 0;
let newLeadsCount = 0;
let currentTarget = 20;
let currentStatus = 'siap';
let currentBusinessName = '';

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function randomDelay(min, max) {
  return sleep(min + Math.random() * (max - min));
}

function getFeed() {
  return document.querySelector('div[role="feed"]');
}

function getResultCards() {
  const feed = getFeed();
  if (!feed) return [];
  const anchors = Array.from(feed.querySelectorAll('a[href*="/maps/place/"]'));
  const seen = new Set();
  const cards = [];
  for (const a of anchors) {
    const cleanHref = a.href.split('?')[0];
    if (seen.has(cleanHref)) continue;
    seen.add(cleanHref);
    cards.push(a);
  }
  return cards;
}

async function scrollFeedForMore() {
  const feed = getFeed();
  if (!feed) return;

  const cards = feed.querySelectorAll('a[href*="/maps/place/"]');
  if (cards.length > 0) {
    cards[cards.length - 1].scrollIntoView({ behavior: 'smooth', block: 'end' });
  } else {
    feed.scrollTop = feed.scrollHeight;
  }
  await randomDelay(800, 1400);
}

function findByAria(prefixes, contains = false) {
  const all = document.querySelectorAll('[aria-label]');
  for (const el of all) {
    const label = (el.getAttribute('aria-label') || '').trim();
    if (!label) continue;
    const lower = label.toLowerCase();
    for (const p of prefixes) {
      const plower = p.toLowerCase();
      if (contains ? lower.includes(plower) : lower.startsWith(plower)) {
        return { el, label };
      }
    }
  }
  return null;
}

function stripPrefix(label, prefixes) {
  for (const p of prefixes) {
    if (label.toLowerCase().startsWith(p.toLowerCase())) {
      return label.slice(p.length).trim();
    }
  }
  return label.trim();
}

// Un-wrap Google redirect URLs dan validasi website
function cleanAndExtractWebsiteUrl(rawUrl, rawText = '') {
  let url = (rawUrl || '').trim();
  const text = (rawText || '').trim();

  // 1. Un-wrap Google redirect: https://www.google.com/url?q=https://topscore.id&...
  if (url.includes('google.com/url') || url.includes('/url?')) {
    try {
      const parsed = new URL(url.startsWith('http') ? url : 'https://www.google.com' + url);
      const target = parsed.searchParams.get('q') || parsed.searchParams.get('url');
      if (target) url = decodeURIComponent(target);
    } catch (e) {
      const match = url.match(/[?&](?:q|url)=([^&]+)/);
      if (match) url = decodeURIComponent(match[1]);
    }
  }

  // 2. Jika text di tombol berupa domain (misal: "topscore.id" atau "www.gudangsepatu.com")
  const domainRegex = /\b[a-zA-Z0-9-]+\.(?:com|id|co\.id|net|org|io|shop|store|online|site|biz|info|my\.id|web\.id)\b/i;
  if (!url || url.includes('google.com')) {
    const match = text.match(domainRegex);
    if (match) {
      url = 'https://' + match[0];
    }
  }

  // 3. Filter out link internal Google Maps / Search
  if (
    url.includes('google.com/maps') ||
    url.includes('google.com/search') ||
    url.includes('gstatic.com') ||
    url.includes('goo.gl/maps') ||
    url.includes('waze.com')
  ) {
    return '';
  }

  return url;
}

function extractCardPreview(cardAnchor) {
  const name = cardAnchor.getAttribute('aria-label') || cardAnchor.textContent.trim() || '';
  const cleanHref = cardAnchor.href.split('?')[0];
  const cardContainer = cardAnchor.closest('div.Nv2PK') || cardAnchor.closest('[role="feed"] > div') || cardAnchor.parentElement;

  let rating = '';
  let reviewCount = '';
  let category = '';
  let addressSnippet = '';

  if (cardContainer) {
    const starEl = cardContainer.querySelector('span[role="img"][aria-label*="bintang" i], span[role="img"][aria-label*="star" i]');
    if (starEl) {
      const label = starEl.getAttribute('aria-label') || '';
      const match = label.match(/([\d\.,]+)/);
      if (match) rating = match[1].replace(',', '.');
    }
    if (!rating) {
      const textMatch = cardContainer.textContent.match(/\b([1-5][\.,]\d)\b/);
      if (textMatch) rating = textMatch[1].replace(',', '.');
    }

    const reviewEl = cardContainer.querySelector('span[aria-label*="ulasan" i], span[aria-label*="review" i]');
    if (reviewEl) {
      const label = reviewEl.getAttribute('aria-label') || reviewEl.textContent || '';
      const match = label.match(/([\d\.,]+)/);
      if (match) reviewCount = match[1].replace(/[^\d]/g, '');
    }
    if (!reviewCount) {
      const parenMatch = cardContainer.textContent.match(/\(([\d\.,]+)\)/);
      if (parenMatch) reviewCount = parenMatch[1].replace(/[^\d]/g, '');
    }

    const textLines = Array.from(cardContainer.querySelectorAll('.fontBodyMedium, .W4Efsd, div'))
      .map(el => el.textContent.trim())
      .filter(t => t.length > 0 && !t.includes(name));

    for (const line of textLines) {
      if (line.includes('·')) {
        const parts = line.split('·').map(p => p.trim());
        if (parts[0] && !category && !parts[0].match(/^[1-5][\.,]\d/)) {
          category = parts[0];
        }
        if (parts[1] && !addressSnippet) {
          addressSnippet = parts[1];
        }
      }
    }
  }

  return {
    name,
    rating,
    reviewCount,
    category,
    addressSnippet,
    mapsUrl: cleanHref
  };
}

async function waitForDetailPanel(timeoutMs = 4000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const hasHeader = document.querySelector('h1') || document.querySelector('[role="main"] h1');
    const hasDetails = document.querySelector('button[data-item-id], button.CsEnBe, a[href^="tel:"], a[data-item-id="authority"], button[aria-label="Tutup"], button[aria-label="Close"]');
    if (hasHeader && hasDetails) return true;
    await sleep(150);
  }
  return false;
}

function extractDetailFromPanel(preview) {
  const nameEl = document.querySelector('h1') || document.querySelector('[role="main"] h1');
  const name = preview.name || (nameEl && nameEl.textContent.trim()) || '(tanpa nama)';

  // 1. Alamat
  let address = '';
  const addrBtn = document.querySelector('button[data-item-id="address"], button[data-tooltip*="alamat" i], button[data-tooltip*="address" i]');
  if (addrBtn) {
    const aria = addrBtn.getAttribute('aria-label') || '';
    address = stripPrefix(aria, ['Alamat:', 'Address:', 'Salin alamat:', 'Salin alamat']);
    if (!address) address = addrBtn.textContent.trim();
  }
  if (!address) {
    const addressMatch = findByAria(['Address:', 'Alamat:', 'Salin alamat']);
    if (addressMatch) address = stripPrefix(addressMatch.label, ['Address:', 'Alamat:', 'Salin alamat:', 'Salin alamat']);
  }
  if (!address && preview.addressSnippet) {
    address = preview.addressSnippet;
  }

  // 2. Nomor Telepon
  let phone = '';
  const telLink = document.querySelector('a[href^="tel:"]');
  if (telLink) {
    phone = telLink.getAttribute('href').replace(/^tel:/i, '').trim();
    if (!phone) phone = telLink.textContent.trim();
  }
  if (!phone) {
    const phoneBtn = document.querySelector('button[data-item-id^="phone:tel:"], button[data-tooltip*="telepon" i], button[data-tooltip*="phone" i]');
    if (phoneBtn) {
      const dataId = phoneBtn.getAttribute('data-item-id') || '';
      if (dataId.startsWith('phone:tel:')) {
        phone = dataId.replace('phone:tel:', '').trim();
      }
      if (!phone) {
        const aria = phoneBtn.getAttribute('aria-label') || '';
        phone = stripPrefix(aria, ['Telepon:', 'Phone:', 'Salin nomor telepon:', 'Salin nomor telepon', 'Panggil:']);
      }
      if (!phone) phone = phoneBtn.textContent.trim();
    }
  }
  if (!phone) {
    const phoneMatch = findByAria(['Phone:', 'Telepon:', 'Salin nomor telepon', 'Nomor telepon:']);
    if (phoneMatch) phone = stripPrefix(phoneMatch.label, ['Phone:', 'Telepon:', 'Salin nomor telepon:', 'Salin nomor telepon', 'Nomor telepon:']);
  }
  if (!phone) {
    const mainText = document.querySelector('[role="main"]')?.textContent || '';
    const phoneRegex = /(?:\+62|62|08|02\d)[\d\s\-\.]{7,15}/;
    const match = mainText.match(phoneRegex);
    if (match) phone = match[0].trim();
  }

  // 3. Website - DENGAN PARSER UN-WRAP GOOGLE REDIRECT & DOMAIN CHECKER
  let website = '';
  
  // A. Cari elemen authority resmi
  const authorityEl = document.querySelector('[data-item-id="authority"]');
  if (authorityEl) {
    const linkEl = authorityEl.tagName === 'A' ? authorityEl : authorityEl.querySelector('a');
    const rawHref = linkEl ? linkEl.getAttribute('href') : authorityEl.getAttribute('href');
    const rawText = authorityEl.textContent.trim();
    website = cleanAndExtractWebsiteUrl(rawHref, rawText);
  }

  // B. Cari link dengan aria-label atau tooltip situs web
  if (!website) {
    const webLinks = Array.from(document.querySelectorAll('a[aria-label*="situs" i], a[aria-label*="website" i], a[data-tooltip*="situs" i], a[data-tooltip*="website" i]'));
    for (const link of webLinks) {
      const cleaned = cleanAndExtractWebsiteUrl(link.getAttribute('href'), link.textContent);
      if (cleaned) {
        website = cleaned;
        break;
      }
    }
  }

  // C. Cari dari prefix aria
  if (!website) {
    const webMatch = findByAria(['Website:', 'Situs web:', 'Situs Web:', 'Kunjungi situs']);
    if (webMatch) {
      const rawHref = webMatch.el.tagName === 'A' ? webMatch.el.getAttribute('href') : webMatch.el.querySelector('a')?.getAttribute('href');
      website = cleanAndExtractWebsiteUrl(rawHref, webMatch.label);
    }
  }

  // D. Deteksi tombol website berbasis icon atau class umum
  if (!website) {
    const actionAnchors = Array.from(document.querySelectorAll('[role="main"] a[href^="http"], [role="main"] a[href^="/url?"]'));
    for (const a of actionAnchors) {
      const cleaned = cleanAndExtractWebsiteUrl(a.getAttribute('href'), a.textContent);
      if (cleaned) {
        website = cleaned;
        break;
      }
    }
  }

  // 4. Kategori
  let category = preview.category || '';
  const catBtn = document.querySelector('button[jsaction="pane.rating.category"], button.DkEaL, button[jsaction*="category"]');
  if (catBtn && catBtn.textContent.trim()) {
    category = catBtn.textContent.trim();
  } else if (!category) {
    const fallbackBtn = document.querySelector('.fontBodyMedium button');
    if (fallbackBtn) category = fallbackBtn.textContent.trim();
  }

  // 5. Rating & Ulasan
  let rating = preview.rating || '';
  let reviewCount = preview.reviewCount || '';

  const detailRatingEl = document.querySelector('div.F7nice span[aria-hidden="true"]');
  if (detailRatingEl && detailRatingEl.textContent.trim()) {
    rating = detailRatingEl.textContent.trim().replace(',', '.');
  }

  const detailReviewEl = document.querySelector('div.F7nice span[aria-label*="ulasan" i], div.F7nice span[aria-label*="review" i]');
  if (detailReviewEl) {
    const rMatch = (detailReviewEl.getAttribute('aria-label') || detailReviewEl.textContent).match(/([\d\.,]+)/);
    if (rMatch) reviewCount = rMatch[1].replace(/[^\d]/g, '');
  }

  return {
    name,
    rating: rating || '',
    reviewCount: reviewCount || '',
    category: category || '',
    address: address || '',
    phone: phone || '',
    website: website || '',
    hasWebsite: !!website,
    mapsUrl: preview.mapsUrl || window.location.href,
    scrapedAt: new Date().toISOString(),
  };
}

function findDetailCloseButton() {
  const detailPanel = document.querySelector('[role="main"]') || document.body;
  const btn = detailPanel.querySelector(
    'button[aria-label="Tutup"], button[aria-label="Close"], ' +
    'button[aria-label="Kembali"], button[aria-label="Back"], ' +
    'button[aria-label^="Kembali ke"], button[aria-label^="Back to"], ' +
    'button[data-tooltip="Tutup"], button[data-tooltip="Close"], ' +
    'button[jsaction*="pane.close"], button[jsaction*="pane.place.backToList"], ' +
    'button.VfPpkd-icon-LgbsSe[aria-label*="Tutup" i], button.VfPpkd-icon-LgbsSe[aria-label*="Close" i]'
  );
  if (btn) return btn;

  return document.querySelector(
    'button[aria-label="Tutup"]:not([aria-label*="penelusuran" i]), ' +
    'button[aria-label="Close"]:not([aria-label*="search" i]), ' +
    'button[aria-label="Kembali"], button[aria-label="Back"]'
  );
}

async function saveLead(lead) {
  const { leads = [] } = await chrome.storage.local.get('leads');
  const dupIndex = leads.findIndex((l) => {
    if (l.mapsUrl && lead.mapsUrl && l.mapsUrl === lead.mapsUrl) return true;
    return l.name.toLowerCase().trim() === lead.name.toLowerCase().trim() &&
           (l.address || '').toLowerCase().trim() === (lead.address || '').toLowerCase().trim();
  });

  let isNew = true;
  if (dupIndex >= 0) {
    leads[dupIndex] = { ...leads[dupIndex], ...lead };
    isNew = false;
  } else {
    leads.push(lead);
  }
  await chrome.storage.local.set({ leads });
  return { total: leads.length, isNew };
}

function reportProgress(count, target, status, businessName = '') {
  processedCount = count;
  currentTarget = target;
  currentStatus = status;
  if (businessName) currentBusinessName = businessName;

  const progressData = {
    type: 'SCRAPE_PROGRESS',
    count: processedCount,
    newCount: newLeadsCount,
    target: currentTarget,
    status: currentStatus,
    businessName: currentBusinessName,
    isRunning,
    version: SCRIPT_VERSION,
    timestamp: Date.now()
  };

  chrome.storage.local.set({ scrapeProgress: progressData }).catch(() => {});
  chrome.runtime.sendMessage(progressData).catch(() => {});

  updateFloatingWidgetUI(processedCount, currentTarget, currentStatus, currentBusinessName, newLeadsCount);
}

async function runScrape(target) {
  if (isRunning) return;
  isRunning = true;
  shouldStop = false;
  currentTarget = target;
  processedCount = 0;
  newLeadsCount = 0;

  if (!getFeed()) {
    reportProgress(0, target, 'no_feed');
    isRunning = false;
    return;
  }

  const { leads: existingLeads = [] } = await chrome.storage.local.get('leads');
  const existingUrls = new Set(existingLeads.map((l) => (l.mapsUrl || '').split('?')[0]).filter(Boolean));
  const existingNames = new Set(existingLeads.map((l) => (l.name || '').toLowerCase().trim()).filter(Boolean));

  const processedUrls = new Set();
  let finishStatus = null;
  let stagnantScrolls = 0;

  reportProgress(0, target, 'jalan', 'Memulai...');

  while (isRunning && !shouldStop && processedCount < target) {
    const cards = getResultCards();
    const unprocessed = cards.filter((c) => !processedUrls.has(c.href.split('?')[0]));

    if (unprocessed.length === 0) {
      reportProgress(processedCount, target, 'jalan', 'Memuat lebih banyak hasil...');
      await scrollFeedForMore();
      stagnantScrolls += 1;
      if (stagnantScrolls > 8) {
        finishStatus = 'habis';
        break;
      }
      continue;
    }
    stagnantScrolls = 0;

    const card = unprocessed[0];
    const cleanUrl = card.href.split('?')[0];
    processedUrls.add(cleanUrl);

    const cardPreview = extractCardPreview(card);
    const cleanName = (cardPreview.name || '').toLowerCase().trim();

    // LEWATI JIKA SUDAH PERNAH TERSIMPAN DI DATABASE (MENCEGAH DUPLIKAT & HEMAT WAKTU)
    if (existingUrls.has(cleanUrl) || (cleanName && existingNames.has(cleanName))) {
      reportProgress(processedCount, target, 'jalan', `Skip: ${cardPreview.name} (sudah ada)`);
      continue;
    }

    processedCount += 1;
    reportProgress(processedCount, target, 'jalan', cardPreview.name || 'Membuka...');

    try {
      card.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await sleep(200);
      card.click();

      await waitForDetailPanel(3500);
      await randomDelay(300, 600);

      const lead = extractDetailFromPanel(cardPreview);
      const { isNew } = await saveLead(lead);
      if (isNew) newLeadsCount += 1;

      const webStatusLabel = lead.hasWebsite ? 'Ada Web' : 'Tanpa Web';
      reportProgress(processedCount, target, 'jalan', `${lead.name} [${webStatusLabel}]`);
    } catch (e) {
      console.warn('GMLF: Error parsing card, fallback to preview', e);
      await saveLead(cardPreview);
    }

    if (shouldStop || processedCount >= target) break;

    const feedStillVisible = !!getFeed();
    if (!feedStillVisible) {
      const closeBtn = findDetailCloseButton();
      if (closeBtn) closeBtn.click();
      else window.history.back();
      await sleep(1000);
    } else {
      const closeBtn = findDetailCloseButton();
      if (closeBtn) {
        closeBtn.click();
        await sleep(300);
      }
    }

    await randomDelay(500, 1000);
  }

  isRunning = false;
  if (!finishStatus) {
    finishStatus = shouldStop ? 'berhenti' : 'selesai';
  }
  reportProgress(processedCount, target, finishStatus, `Selesai (${newLeadsCount} data baru)`);
}

// -------------------------------------------------------------
// FLOATING IN-PAGE CONTROLLER WIDGET
// -------------------------------------------------------------
function injectFloatingWidget() {
  if (document.getElementById('gmlf-widget')) return;

  const style = document.createElement('style');
  style.id = 'gmlf-styles';
  style.textContent = `
    #gmlf-widget {
      position: fixed;
      bottom: 24px;
      right: 24px;
      width: 310px;
      background: rgba(15, 23, 42, 0.95);
      backdrop-filter: blur(14px);
      -webkit-backdrop-filter: blur(14px);
      border: 1px solid rgba(51, 65, 85, 0.9);
      border-radius: 16px;
      box-shadow: 0 16px 36px -4px rgba(0, 0, 0, 0.7), 0 0 0 1px rgba(255, 255, 255, 0.1);
      color: #f8fafc;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      z-index: 99999999;
      box-sizing: border-box;
      overflow: hidden;
      user-select: none;
    }
    #gmlf-widget * { box-sizing: border-box; font-family: inherit; }
    #gmlf-header {
      padding: 12px 14px;
      background: rgba(30, 41, 59, 0.85);
      border-bottom: 1px solid rgba(51, 65, 85, 0.8);
      display: flex;
      align-items: center;
      justify-content: space-between;
      cursor: grab;
    }
    #gmlf-header:active { cursor: grabbing; }
    #gmlf-title {
      font-size: 13px;
      font-weight: 700;
      color: #38bdf8;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .gmlf-icon-btn {
      background: transparent;
      border: none;
      color: #94a3b8;
      cursor: pointer;
      font-size: 14px;
      padding: 2px 6px;
      border-radius: 4px;
      line-height: 1;
    }
    .gmlf-icon-btn:hover { background: rgba(255, 255, 255, 0.1); color: #fff; }
    #gmlf-body { padding: 14px; }
    .gmlf-row { margin-bottom: 12px; }
    .gmlf-target-label {
      font-size: 11.5px;
      color: #94a3b8;
      margin-bottom: 4px;
      display: block;
    }
    #gmlf-target {
      width: 100%;
      background: #090d16;
      border: 1px solid #334155;
      border-radius: 8px;
      padding: 7px 10px;
      color: #fff;
      font-size: 13px;
    }
    #gmlf-target:focus { outline: 1px solid #38bdf8; border-color: #38bdf8; }
    .gmlf-btn-group { display: flex; gap: 8px; }
    .gmlf-btn {
      flex: 1;
      padding: 8px 12px;
      border-radius: 8px;
      border: none;
      font-size: 12.5px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 5px;
      transition: all 0.15s ease;
    }
    .gmlf-btn-start { background: #10b981; color: #ffffff; }
    .gmlf-btn-start:hover { background: #059669; }
    .gmlf-btn-start:disabled { opacity: 0.5; cursor: not-allowed; }
    .gmlf-btn-stop { background: #ef4444; color: #ffffff; }
    .gmlf-btn-stop:hover { background: #dc2626; }
    .gmlf-btn-stop:disabled { opacity: 0.4; cursor: not-allowed; }
    #gmlf-progress-wrap {
      background: rgba(15, 23, 42, 0.7);
      border: 1px solid #1e293b;
      border-radius: 10px;
      padding: 10px;
      margin-top: 10px;
    }
    .gmlf-prog-header {
      display: flex;
      justify-content: space-between;
      font-size: 11.5px;
      font-weight: 600;
      color: #cbd5e1;
      margin-bottom: 6px;
    }
    .gmlf-bar-bg {
      height: 6px;
      background: #1e293b;
      border-radius: 999px;
      overflow: hidden;
    }
    #gmlf-bar-fill {
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, #10b981, #38bdf8);
      transition: width 0.25s ease;
    }
    #gmlf-status-text {
      font-size: 11px;
      color: #94a3b8;
      margin-top: 6px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .gmlf-footer-links {
      display: flex;
      gap: 8px;
      margin-top: 12px;
      padding-top: 10px;
      border-top: 1px solid rgba(51, 65, 85, 0.6);
    }
    .gmlf-link-btn {
      flex: 1;
      padding: 6px 8px;
      background: rgba(51, 65, 85, 0.4);
      border: 1px solid rgba(51, 65, 85, 0.8);
      border-radius: 6px;
      color: #cbd5e1;
      font-size: 11.5px;
      cursor: pointer;
      text-align: center;
    }
    .gmlf-link-btn:hover { background: rgba(51, 65, 85, 0.8); color: #fff; }
    #gmlf-pill {
      display: none;
      padding: 10px 14px;
      cursor: pointer;
      font-size: 12px;
      font-weight: 600;
      color: #38bdf8;
      align-items: center;
      gap: 8px;
    }
    #gmlf-pill:hover { background: rgba(30, 41, 59, 0.9); }
  `;
  document.head.appendChild(style);

  const widget = document.createElement('div');
  widget.id = 'gmlf-widget';
  widget.innerHTML = `
    <div id="gmlf-header">
      <div id="gmlf-title">📍 GMaps Lead Finder</div>
      <button class="gmlf-icon-btn" id="gmlf-min-btn" title="Minimize">_</button>
    </div>
    <div id="gmlf-pill">📍 GMaps Scraper: <span id="gmlf-pill-count">0/20</span> (Klik untuk buka)</div>
    <div id="gmlf-body">
      <div class="gmlf-row">
        <label class="gmlf-target-label" for="gmlf-target">Target Data Sesi Ini:</label>
        <input type="number" id="gmlf-target" min="1" max="1000" value="20" />
      </div>
      <div class="gmlf-row">
        <div class="gmlf-btn-group">
          <button class="gmlf-btn gmlf-btn-start" id="gmlf-start-btn">▶ Mulai</button>
          <button class="gmlf-btn gmlf-btn-stop" id="gmlf-stop-btn" disabled>⏹ Stop</button>
        </div>
      </div>
      <div id="gmlf-progress-wrap">
        <div class="gmlf-prog-header">
          <span id="gmlf-status-pill">Siap</span>
          <span id="gmlf-count-label">0 / 20</span>
        </div>
        <div class="gmlf-bar-bg">
          <div id="gmlf-bar-fill"></div>
        </div>
        <div id="gmlf-status-text">Buka pencarian Maps, lalu tekan Mulai</div>
      </div>
      <div class="gmlf-footer-links">
        <button class="gmlf-link-btn" id="gmlf-table-btn">📋 Buka Tabel Hasil</button>
      </div>
    </div>
  `;
  document.body.appendChild(widget);

  const header = widget.querySelector('#gmlf-header');
  let isDragging = false, startX, startY, initialLeft, initialTop;

  header.addEventListener('mousedown', (e) => {
    if (e.target.closest('button')) return;
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    const rect = widget.getBoundingClientRect();
    initialLeft = rect.left;
    initialTop = rect.top;
    widget.style.bottom = 'auto';
    widget.style.right = 'auto';
    widget.style.left = initialLeft + 'px';
    widget.style.top = initialTop + 'px';
  });

  window.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    widget.style.left = Math.max(10, Math.min(window.innerWidth - widget.offsetWidth - 10, initialLeft + dx)) + 'px';
    widget.style.top = Math.max(10, Math.min(window.innerHeight - widget.offsetHeight - 10, initialTop + dy)) + 'px';
  });

  window.addEventListener('mouseup', () => { isDragging = false; });

  const minBtn = widget.querySelector('#gmlf-min-btn');
  const body = widget.querySelector('#gmlf-body');
  const pill = widget.querySelector('#gmlf-pill');

  minBtn.addEventListener('click', () => {
    body.style.display = 'none';
    header.style.display = 'none';
    pill.style.display = 'flex';
  });

  pill.addEventListener('click', () => {
    body.style.display = 'block';
    header.style.display = 'flex';
    pill.style.display = 'none';
  });

  const startBtn = widget.querySelector('#gmlf-start-btn');
  const stopBtn = widget.querySelector('#gmlf-stop-btn');
  const targetInput = widget.querySelector('#gmlf-target');
  const tableBtn = widget.querySelector('#gmlf-table-btn');

  startBtn.addEventListener('click', () => {
    const t = parseInt(targetInput.value, 10) || 20;
    runScrape(t);
  });

  stopBtn.addEventListener('click', () => {
    shouldStop = true;
    reportProgress(processedCount, currentTarget, 'berhenti', 'Menghentikan proses...');
  });

  tableBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'OPEN_TABLE' });
  });

  chrome.storage.local.get(['scrapeProgress', 'leads'], ({ scrapeProgress, leads = [] }) => {
    if (scrapeProgress && scrapeProgress.status === 'jalan') {
      updateFloatingWidgetUI(scrapeProgress.count, scrapeProgress.target, scrapeProgress.status, scrapeProgress.businessName, scrapeProgress.newCount);
    } else if (leads.length > 0) {
      widget.querySelector('#gmlf-status-text').textContent = `Tersimpan ${leads.length} data bisnis di memori`;
    }
  });
}

function updateFloatingWidgetUI(count, target, status, businessName = '', newCount = 0) {
  const widget = document.getElementById('gmlf-widget');
  if (!widget) return;

  const startBtn = widget.querySelector('#gmlf-start-btn');
  const stopBtn = widget.querySelector('#gmlf-stop-btn');
  const targetInput = widget.querySelector('#gmlf-target');
  const countLabel = widget.querySelector('#gmlf-count-label');
  const pillCount = widget.querySelector('#gmlf-pill-count');
  const fill = widget.querySelector('#gmlf-bar-fill');
  const statusPill = widget.querySelector('#gmlf-status-pill');
  const statusText = widget.querySelector('#gmlf-status-text');

  const running = status === 'jalan';
  startBtn.disabled = running;
  stopBtn.disabled = !running;
  targetInput.disabled = running;

  const pct = target > 0 ? Math.min(100, Math.round((count / target) * 100)) : 0;
  fill.style.width = pct + '%';
  countLabel.textContent = `${count} / ${target}`;
  if (pillCount) pillCount.textContent = `${count}/${target}`;

  if (running) {
    statusPill.textContent = '● Scraping...';
    statusPill.style.color = '#10b981';
    statusText.textContent = businessName ? `Proses: ${businessName}` : 'Sedang memproses...';
  } else if (status === 'selesai') {
    statusPill.textContent = '✓ Selesai';
    statusPill.style.color = '#38bdf8';
    statusText.textContent = `Selesai! ${count} diproses (${newCount} data baru)`;
  } else if (status === 'berhenti') {
    statusPill.textContent = '⏹ Dihentikan';
    statusPill.style.color = '#f59e0b';
    statusText.textContent = 'Dihentikan oleh pengguna';
  } else if (status === 'habis') {
    statusPill.textContent = 'Semua Terambil';
    statusPill.style.color = '#94a3b8';
    statusText.textContent = 'Semua hasil pencarian Maps sudah diambil';
  } else if (status === 'no_feed') {
    statusPill.textContent = '⚠️ Belum Search';
    statusPill.style.color = '#ef4444';
    statusText.textContent = 'Cari bisnis di Maps dulu (sidebar harus tampil)';
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectFloatingWidget);
} else {
  injectFloatingWidget();
}
setTimeout(injectFloatingWidget, 1000);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'START_SCRAPE') {
    if (!isRunning) {
      runScrape(msg.target || 20);
      sendResponse({ ok: true, count: 0, target: msg.target || 20 });
    } else {
      sendResponse({ ok: false, alreadyRunning: true, count: processedCount, target: currentTarget });
    }
  } else if (msg.type === 'STOP_SCRAPE') {
    shouldStop = true;
    sendResponse({ ok: true });
  } else if (msg.type === 'GET_STATUS') {
    sendResponse({
      isRunning,
      count: processedCount,
      newCount: newLeadsCount,
      target: currentTarget,
      status: currentStatus,
      currentBusiness: currentBusinessName,
      version: SCRIPT_VERSION,
    });
  } else if (msg.type === 'PING') {
    injectFloatingWidget();
    sendResponse({ ok: true, version: SCRIPT_VERSION });
  }
  return true;
});
