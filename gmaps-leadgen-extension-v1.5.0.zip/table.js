// table.js
// GMaps Lead Finder - Clean 7-Column Table Controller & Real Data Validator

const tbody = document.getElementById('tbody');
const summary = document.getElementById('summary');
const emptyState = document.getElementById('emptyState');
const searchInput = document.getElementById('search');
const onlyNoWebsite = document.getElementById('onlyNoWebsite');

const exportCsvBtn = document.getElementById('exportCsvBtn');
const exportJsonBtn = document.getElementById('exportJsonBtn');
const syncDashboardBtn = document.getElementById('syncDashboardBtn');
const syncStatus = document.getElementById('syncStatus');
const clearBtn = document.getElementById('clearBtn');
const addManualBtn = document.getElementById('addManualBtn');
const manualForm = document.getElementById('manualForm');

// Form manual
const mName = document.getElementById('mName');
const mCategory = document.getElementById('mCategory');
const mRating = document.getElementById('mRating');
const mReviews = document.getElementById('mReviews');
const mAddress = document.getElementById('mAddress');
const mPhone = document.getElementById('mPhone');
const mWebsite = document.getElementById('mWebsite');
const mMapsUrl = document.getElementById('mMapsUrl');
const mSaveBtn = document.getElementById('mSaveBtn');
const mCancelBtn = document.getElementById('mCancelBtn');

let allLeads = [];
let currentFilteredLeads = [];

// Normalisasi nomor telepon lokal Indonesia ke format wa.me (628...)
function normalizePhoneForWa(phone) {
  if (!phone) return '';
  let digits = phone.replace(/[^\d]/g, '');
  if (digits.startsWith('0')) digits = '62' + digits.slice(1);
  if (!digits.startsWith('62') && digits.length >= 8) digits = '62' + digits;
  return digits;
}

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// BERSINKAN DATA DARI BUG SEBELUMNYA (GOOGLE SUPPORT, BUSINESS CLAIM, WA.ME, SOSMED, EMBEL-EMBEL TEKS)
function cleanLead(l) {
  let name = (l.name || '')
    .replace(/[·\•]\s*(?:Link yang dikunjungi|Visited link|Ditampilkan|Promosi|Iklan|Ad)\b.*/i, '')
    .replace(/^(?:Link yang dikunjungi|Visited link)[·\•\s]*/i, '')
    .replace(/\s*[·\•]\s*$/, '')
    .trim();

  let website = (l.website || '').trim();
  let phone = (l.phone || '').trim();
  let whatsapp = (l.whatsapp || '').trim();
  let address = (l.address || '').trim();

  // Daftar domain yang BUKAN website toko mandiri
  const bannedDomains = [
    'google.com', 'google.co.id', 'google.co.jp', 'google.co.uk', 'google.de',
    'google.fr', 'google.it', 'google.es', 'google.ca', 'google.com.au',
    'business.google.com', 'support.google.com', 'maps.google.com', 'play.google.com',
    'accounts.google.com', 'docs.google.com', 'drive.google.com',
    'gstatic.com', 'googleapis.com', 'googleusercontent.com',
    'goo.gl', 'g.co', 'g.page',
    'waze.com',
    'wa.me', 'whatsapp.com', 'api.whatsapp.com',
    'instagram.com', 'www.instagram.com',
    'facebook.com', 'www.facebook.com', 'fb.com', 'fb.me', 'm.facebook.com',
    'tiktok.com', 'www.tiktok.com', 'vm.tiktok.com',
    'twitter.com', 'x.com', 'mobile.twitter.com',
    'youtube.com', 'www.youtube.com', 'youtu.be', 'm.youtube.com',
    'linktr.ee', 'bit.ly', 'tinyurl.com', 's.id', 'rebrand.ly',
    'shopee.co.id', 'shopee.com', 'shopee.sg',
    'tokopedia.com', 'www.tokopedia.com',
    'lazada.co.id', 'lazada.com',
    'blibli.com', 'www.blibli.com',
    'bukalapak.com', 'www.bukalapak.com',
    'grab.com', 'gojek.com', 'grabfood.com', 'shopeefood.co.id',
    'tripadvisor.com', 'tripadvisor.co.id',
    'traveloka.com', 'tiket.com',
    'linkedin.com', 'pinterest.com', 'reddit.com', 'telegram.org', 't.me',
    'apple.com', 'apps.apple.com', 'itunes.apple.com'
  ];

  // Jika sebelumnya salah mengambil link wa.me sebagai website, pindahkan ke nomor whatsapp
  if (website.toLowerCase().includes('wa.me') || website.toLowerCase().includes('whatsapp.com')) {
    const waMatch = website.match(/(?:wa\.me\/|phone=)(?:62|0)?(\d+)/);
    if (waMatch && !whatsapp) whatsapp = '0' + waMatch[1];
    website = '';
  }

  // Jika whatsapp kosong tapi phone adalah nomor HP Indonesia (08... atau 628...), set whatsapp = phone
  if (!whatsapp && phone) {
    const digits = phone.replace(/[^\d]/g, '');
    if (digits.startsWith('08') || digits.startsWith('628') || digits.startsWith('8')) {
      whatsapp = phone;
    }
  }

  // Jika mengandung domain terlarang, hapus websitenya
  const lowerWeb = website.toLowerCase();
  if (bannedDomains.some((b) => lowerWeb.includes(b)) || lowerWeb.includes('google.')) {
    website = '';
  }

  // Bersihkan alamat dari artefak jam buka/tutup/segera
  address = address
    .replace(/[·\s]*(?:Buka|Tutup|Segera)\s*[·\-–—]?\s*(?:Tutup|Buka|Segera)?\s*(?:pukul)?\s*\d{1,2}[\.:]?\d{0,2}(?:\s*[–\-]\s*\d{1,2}[\.:]?\d{0,2})?/gi, '')
    .replace(/[·\s]*(?:Buka|Tutup|Segera)\s*(?:24 jam|sementara|selamanya|permanen)?/gi, '')
    .replace(/(?:Buka|Tutup|Segera)$/gi, '')
    .replace(/\b(?:Buka|Tutup|Segera)\b/gi, '')
    .replace(/^[\s·\-–—,;]+|[\s·\-–—,;]+$/g, '')
    .trim();

  // Bersihkan nomor telepon
  if (phone) {
    phone = phone.replace(/[^\d+\-() ]/g, '').trim();
  }
  if (whatsapp) {
    whatsapp = whatsapp.replace(/[^\d+\-() ]/g, '').trim();
  }

  // Validasi rating: harus 1.0-5.0
  let rating = (l.rating || '').toString().trim();
  if (rating) {
    const rVal = parseFloat(rating.replace(',', '.'));
    if (isNaN(rVal) || rVal < 1.0 || rVal > 5.0) rating = '';
    else rating = rVal.toFixed(1);
  }

  // Bersihkan review count palsu hasil bug lama (misal rating 4.4 jadi 44, 5.0 jadi 50, 4.7 jadi 47, 4.9 jadi 49)
  let reviewCount = (l.reviewCount || '').toString().trim();
  if (rating && reviewCount) {
    const rNum = parseFloat(rating.replace(',', '.'));
    const revNum = parseInt(reviewCount, 10);
    if (!isNaN(rNum) && !isNaN(revNum) && revNum === Math.round(rNum * 10)) {
      reviewCount = ''; // Bersihkan data palsu dari memori lama
    }
  }

  const hasWebsite = !!website && website.includes('.');

  return {
    ...l,
    name,
    website,
    phone,
    whatsapp,
    address,
    rating,
    reviewCount,
    hasWebsite
  };
}

// Render tabel utama 7 kolom (bersih, rapi, persis seperti screenshot awal)
function render() {
  const query = searchInput.value.trim().toLowerCase();
  const filterNoSite = onlyNoWebsite.checked;

  currentFilteredLeads = allLeads.filter((l) => {
    if (filterNoSite && l.hasWebsite) return false;
    if (!query) return true;
    return (
      (l.name || '').toLowerCase().includes(query) ||
      (l.address || '').toLowerCase().includes(query) ||
      (l.category || '').toLowerCase().includes(query) ||
      (l.phone || '').toLowerCase().includes(query)
    );
  });

  summary.textContent = `${currentFilteredLeads.length} data ditampilkan (dari ${allLeads.length} total tersimpan)`;

  tbody.innerHTML = '';
  emptyState.hidden = currentFilteredLeads.length > 0;

  for (let i = 0; i < currentFilteredLeads.length; i++) {
    const lead = currentFilteredLeads[i];
    const tr = document.createElement('tr');

    // Website Cell
    const websiteCell = lead.hasWebsite
      ? `<a class="site-link" href="${escapeHtml(lead.website)}" target="_blank" rel="noopener">${escapeHtml(lead.website)}</a>`
      : `<span class="badge no">Belum ada</span>`;

    // Aksi WA
    const waDigits = normalizePhoneForWa(lead.whatsapp || lead.phone);
    const waButton = waDigits
      ? `<a class="btn-wa" href="https://wa.me/${waDigits}" target="_blank" rel="noopener">Chat WA</a>`
      : `<span class="disabled">No WA</span>`;

    // Aksi Maps
    const mapsLink = lead.mapsUrl
      ? `<a class="maps-link" href="${escapeHtml(lead.mapsUrl)}" target="_blank" rel="noopener">Buka Maps</a>`
      : `<span class="disabled">Maps</span>`;

    // Format jumlah ulasan asli (misal: "1", "47", "1.989", "2.287")
    let reviewCountFormatted = '';
    if (lead.reviewCount) {
      const num = parseInt(lead.reviewCount, 10);
      reviewCountFormatted = isNaN(num) ? lead.reviewCount : num.toLocaleString('id-ID');
    }

    // Rating Display (Contoh: ★ 5.0 (1))
    const ratingDisplay = lead.rating 
      ? `<span style="color:#d97706;font-weight:600;">★ ${escapeHtml(lead.rating)}</span>${reviewCountFormatted ? ` <span style="color:#64748b;font-size:11.5px;">(${escapeHtml(reviewCountFormatted)})</span>` : ''}`
      : `<span style="color:#94a3b8;">-</span>`;

    // 7 Kolom Bersih
    tr.innerHTML = `
      <td class="name-cell">
        <div>${escapeHtml(lead.name)}</div>
      </td>
      <td>${ratingDisplay}</td>
      <td class="muted-cell">${escapeHtml(lead.category || '-')}</td>
      <td class="address-cell">${escapeHtml(lead.address || '-')}</td>
      <td>${lead.phone ? escapeHtml(lead.phone) : '<span style="color:#94a3b8;">-</span>'}</td>
      <td>${websiteCell}</td>
      <td class="action-cell">
        ${waButton}
        ${mapsLink}
      </td>
    `;

    tbody.appendChild(tr);
  }
}

// Muat data dari storage
async function load() {
  const { leads = [] } = await chrome.storage.local.get('leads');
  allLeads = (leads || []).map(cleanLead);
  await chrome.storage.local.set({ leads: allLeads });
  render();
}

// Event Listeners
searchInput.addEventListener('input', render);
onlyNoWebsite.addEventListener('change', render);

// Tambah manual
addManualBtn.addEventListener('click', () => {
  manualForm.hidden = !manualForm.hidden;
  if (!manualForm.hidden) mName.focus();
});

mCancelBtn.addEventListener('click', () => {
  manualForm.hidden = true;
});

mSaveBtn.addEventListener('click', async () => {
  const name = mName.value.trim();
  if (!name) {
    alert('Nama bisnis wajib diisi');
    return;
  }
  const lead = cleanLead({
    name,
    category: mCategory.value.trim(),
    rating: mRating.value.trim(),
    reviewCount: mReviews.value.trim(),
    address: mAddress.value.trim(),
    phone: mPhone.value.trim(),
    website: mWebsite.value.trim(),
    mapsUrl: mMapsUrl.value.trim(),
    hasWebsite: !!mWebsite.value.trim(),
    scrapedAt: new Date().toISOString()
  });

  allLeads.unshift(lead);
  await chrome.storage.local.set({ leads: allLeads });
  render();

  mName.value = '';
  mCategory.value = '';
  mRating.value = '';
  mReviews.value = '';
  mAddress.value = '';
  mPhone.value = '';
  mWebsite.value = '';
  mMapsUrl.value = '';
  manualForm.hidden = true;
});

// Hapus semua data
clearBtn.addEventListener('click', async () => {
  if (confirm('Yakin ingin menghapus semua data yang tersimpan di ekstensi?')) {
    allLeads = [];
    await chrome.storage.local.set({ leads: [] });
    render();
  }
});

// Export CSV
exportCsvBtn.addEventListener('click', () => {
  if (currentFilteredLeads.length === 0) {
    alert('Tidak ada data untuk diekspor');
    return;
  }

  const headers = ['Nama Bisnis', 'Rating', 'Jumlah Ulasan', 'Kategori', 'Alamat', 'Telepon', 'WhatsApp', 'Website', 'Maps URL'];
  const rows = currentFilteredLeads.map((l) => [
    `"${(l.name || '').replace(/"/g, '""')}"`,
    `"${(l.rating || '').replace(/"/g, '""')}"`,
    `"${(l.reviewCount || '').replace(/"/g, '""')}"`,
    `"${(l.category || '').replace(/"/g, '""')}"`,
    `"${(l.address || '').replace(/"/g, '""')}"`,
    `"${(l.phone || '').replace(/"/g, '""')}"`,
    `"${(l.whatsapp || l.phone || '').replace(/"/g, '""')}"`,
    `"${(l.website || '').replace(/"/g, '""')}"`,
    `"${(l.mapsUrl || '').replace(/"/g, '""')}"`
  ]);

  const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `leads-gmaps-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
});

// Export JSON
exportJsonBtn.addEventListener('click', () => {
  if (currentFilteredLeads.length === 0) {
    alert('Tidak ada data untuk diekspor');
    return;
  }
  const jsonContent = JSON.stringify(currentFilteredLeads, null, 2);
  const blob = new Blob([jsonContent], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `leads-gmaps-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
});

// Sinkron ke Web Dashboard
syncDashboardBtn.addEventListener('click', async () => {
  if (allLeads.length === 0) {
    alert('Tidak ada data yang bisa disinkronkan.');
    return;
  }

  syncStatus.style.display = 'block';
  syncStatus.style.background = '#e0f2fe';
  syncStatus.style.color = '#0369a1';
  syncStatus.textContent = '⏳ Sedang mengirim data ke Web Dashboard...';

  try {
    const res = await fetch('http://localhost:3000/api/leads/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ leads: allLeads })
    });

    if (res.ok) {
      const data = await res.json();
      syncStatus.style.background = '#dcfce7';
      syncStatus.style.color = '#15803d';
      syncStatus.textContent = `✅ Berhasil sinkron ${data.synced || allLeads.length} data ke Web Dashboard!`;
    } else {
      throw new Error(`HTTP ${res.status}`);
    }
  } catch (err) {
    syncStatus.style.background = '#fee2e2';
    syncStatus.style.color = '#b91c1c';
    syncStatus.textContent = `⚠️ Gagal sinkron ke localhost:3000 (${err.message}). Pastikan server dashboard menyala.`;
  }

  setTimeout(() => {
    syncStatus.style.display = 'none';
  }, 6000);
});

// Update otomatis jika ada data masuk saat tabel terbuka
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.leads) {
    allLeads = (changes.leads.newValue || []).map(cleanLead);
    render();
  }
});

load();
