// popup.js
const targetInput = document.getElementById('target');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const statusEl = document.getElementById('status');
const progressWrap = document.getElementById('progressWrap');
const progressFill = document.getElementById('progressFill');
const progressLabel = document.getElementById('progressLabel');
const openTableBtn = document.getElementById('openTableBtn');

async function getActiveMapsTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.url && tab.url.includes('google.com/maps')) return tab;
  return null;
}

// Pastikan content script sudah aktif di tab Maps
async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: 'PING' });
    return true;
  } catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
      await new Promise((r) => setTimeout(r, 200));
      return true;
    } catch (err) {
      return false;
    }
  }
}

function setRunningUI(running) {
  startBtn.disabled = running;
  stopBtn.disabled = !running;
  targetInput.disabled = running;
}

function updateProgress(count, target, status, businessName = '') {
  progressWrap.hidden = false;
  const pct = target > 0 ? Math.min(100, Math.round((count / target) * 100)) : 0;
  progressFill.style.width = pct + '%';
  progressLabel.textContent = `${count} / ${target}`;

  let statusText = '';
  if (status === 'jalan') {
    statusText = businessName ? `Sedang mengambil: ${businessName}` : 'Sedang mengambil data...';
  } else if (status === 'selesai') {
    statusText = `Selesai! Target ${count} data tercapai.`;
  } else if (status === 'berhenti') {
    statusText = 'Dihentikan manual.';
  } else if (status === 'habis') {
    statusText = 'Semua hasil pencarian di Google Maps sudah diambil.';
  } else if (status === 'no_feed') {
    statusText = 'Tidak ditemukan daftar hasil. Pastikan berada di halaman search Google Maps dengan sidebar hasil pencarian aktif.';
  }

  if (statusText) statusEl.textContent = statusText;

  if (status === 'selesai' || status === 'berhenti' || status === 'habis' || status === 'no_feed') {
    setRunningUI(false);
  } else if (status === 'jalan') {
    setRunningUI(true);
  }
}

startBtn.addEventListener('click', async () => {
  const tab = await getActiveMapsTab();
  if (!tab) {
    statusEl.textContent = 'Buka tab Google Maps (google.com/maps), cari bisnis yang diinginkan, lalu tekan Mulai.';
    return;
  }

  if (tab.url.includes('/maps/place/')) {
    statusEl.textContent = 'Kamu sedang di halaman satu bisnis. Klik tombol kembali (←/Tutup) di Maps hingga daftar hasil muncul, lalu tekan Mulai lagi.';
    return;
  }

  statusEl.textContent = 'Menyiapkan scraper...';
  const ready = await ensureContentScript(tab.id);
  if (!ready) {
    statusEl.textContent = 'Gagal menghubungkan ke tab Maps. Coba refresh tab Maps (Ctrl+R), lalu tekan Mulai lagi.';
    return;
  }

  const target = parseInt(targetInput.value, 10) || 20;

  chrome.tabs.sendMessage(tab.id, { type: 'START_SCRAPE', target }, (res) => {
    if (chrome.runtime.lastError) {
      statusEl.textContent = 'Error: ' + chrome.runtime.lastError.message + '. Refresh tab Maps lalu coba lagi.';
      setRunningUI(false);
      return;
    }
    setRunningUI(true);
    if (res && res.alreadyRunning) {
      // Jika sedang jalan, jangan reset counter ke 0!
      updateProgress(res.count, res.target, 'jalan');
    } else {
      updateProgress(0, target, 'jalan');
    }
  });
});

stopBtn.addEventListener('click', async () => {
  const tab = await getActiveMapsTab();
  if (tab) chrome.tabs.sendMessage(tab.id, { type: 'STOP_SCRAPE' });
  statusEl.textContent = 'Menghentikan proses...';
});

openTableBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'OPEN_TABLE' });
});

// Dengarkan pesan progress live dari content script
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'SCRAPE_PROGRESS') {
    updateProgress(msg.count, msg.target, msg.status, msg.businessName);
  }
});

// Dengarkan perubahan storage agar selalu sinkron
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.scrapeProgress) {
    const p = changes.scrapeProgress.newValue;
    if (p) updateProgress(p.count, p.target, p.status, p.businessName);
  }
});

// Inisialisasi tampilan saat popup dibuka
(async () => {
  const { leads = [], scrapeProgress } = await chrome.storage.local.get(['leads', 'scrapeProgress']);

  const tab = await getActiveMapsTab();
  if (tab) {
    // Tanya langsung status terkini ke tab aktif
    chrome.tabs.sendMessage(tab.id, { type: 'GET_STATUS' }, (res) => {
      if (!chrome.runtime.lastError && res) {
        if (res.isRunning) {
          setRunningUI(true);
          updateProgress(res.count, res.target, res.status, res.currentBusiness);
          return;
        }
      }
      
      // Fallback ke storage jika tab belum merespons
      if (scrapeProgress && scrapeProgress.status === 'jalan') {
        setRunningUI(true);
        updateProgress(scrapeProgress.count, scrapeProgress.target, scrapeProgress.status, scrapeProgress.businessName);
      } else if (leads.length > 0) {
        statusEl.textContent = `Tersimpan ${leads.length} data bisnis. Tekan Mulai untuk menambah atau gunakan widget melayang di Maps.`;
      }
    });
  } else if (leads.length > 0) {
    statusEl.textContent = `Tersimpan ${leads.length} data bisnis. Buka Google Maps untuk mulai scraping.`;
  }
})();
