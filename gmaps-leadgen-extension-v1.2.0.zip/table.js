// table.js
const tbody = document.getElementById('tbody');
const summary = document.getElementById('summary');
const emptyState = document.getElementById('emptyState');
const searchInput = document.getElementById('search');
const onlyNoWebsite = document.getElementById('onlyNoWebsite');
const exportCsvBtn = document.getElementById('exportCsvBtn');
const exportJsonBtn = document.getElementById('exportJsonBtn');
const syncDashboardBtn = document.getElementById('syncDashboardBtn');
const syncStatus = document.getElementById('syncStatus');
const clearBtn = document.getElementById('clearBtn');
const addManualBtn = document.getElementById('addManualBtn');
const manualForm = document.getElementById('manualForm');

const mName = document.getElementById('mName');
const mCategory = document.getElementById('mCategory');
const mRating = document.getElementById('mRating');
const mReviews = document.getElementById('mReviews');
const mAddress = document.getElementById('mAddress');
const mPhone = document.getElementById('mPhone');
const mWebsite = document.getElementById('mWebsite');
const mMapsUrl = document.getElementById('mMapsUrl');
const mSaveBtn = document.getElementById('mSaveBtn');
const mCancelBtn = document.getElementById('mCancelBtn');

let allLeads = [];
let currentFilteredLeads = [];

// Normalisasi nomor telepon lokal Indonesia ke format wa.me (628...)
function normalizePhoneForWa(phone) {
  if (!phone) return '';
  let digits = phone.replace(/[^\d]/g, '');
  if (digits.startsWith('0')) digits = '62' + digits.slice(1);
  if (!digits.startsWith('62') && digits.length >= 8) digits = '62' + digits;
  return digits;
}

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function render() {
  const query = searchInput.value.trim().toLowerCase();
  const filterNoSite = onlyNoWebsite.checked;

  currentFilteredLeads = allLeads.filter((l) => {
    if (filterNoSite && l.hasWebsite) return false;
    if (!query) return true;
    return (
      (l.name || '').toLowerCase().includes(query) ||
      (l.address || '').toLowerCase().includes(query) ||
      (l.category || '').toLowerCase().includes(query) ||
      (l.phone || '').toLowerCase().includes(query)
    );
  });

  summary.textContent = `${currentFilteredLeads.length} data ditampilkan (dari ${allLeads.length} total tersimpan)`;

  tbody.innerHTML = '';
  emptyState.hidden = currentFilteredLeads.length > 0;

  for (const lead of currentFilteredLeads) {
    const tr = document.createElement('tr');

    const websiteCell = lead.hasWebsite
      ? `<a class="site-link" href="${escapeHtml(lead.website)}" target="_blank" rel="noopener">${escapeHtml(lead.website)}</a>`
      : `<span class="badge no">Belum ada</span>`;

    const waNumber = normalizePhoneForWa(lead.phone);
    const waLink = waNumber
      ? `<a href="https://wa.me/${waNumber}" target="_blank" rel="noopener">Chat WA</a>`
      : `<span class="disabled">Chat WA</span>`;

    const mapsLink = lead.mapsUrl
      ? `<a href="${escapeHtml(lead.mapsUrl)}" target="_blank" rel="noopener">Buka Maps</a>`
      : `<span class="disabled">Buka Maps</span>`;

    const ratingDisplay = lead.rating 
      ? `<span style="color:#d97706;font-weight:600;">★ ${escapeHtml(lead.rating)}</span> <span style="color:#64748b;font-size:11.5px;">(${escapeHtml(lead.reviewCount || '0')})</span>`
      : `<span style="color:#94a3b8;">-</span>`;

    tr.innerHTML = `
      <td class="name-cell">${escapeHtml(lead.name)}</td>
      <td>${ratingDisplay}</td>
      <td class="muted-cell">${escapeHtml(lead.category || '-')}</td>
      <td class="muted-cell" style="max-width:240px;word-break:break-word;">${escapeHtml(lead.address || '-')}</td>
      <td class="muted-cell" style="white-space:nowrap;">${escapeHtml(lead.phone || '-')}</td>
      <td>${websiteCell}</td>
      <td class="muted-cell" style="white-space:nowrap;">${new Date(lead.scrapedAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</td>
      <td><div class="action-links">${mapsLink}${waLink}</div></td>
    `;
    tbody.appendChild(tr);
  }
}

async function loadLeads() {
  const { leads = [] } = await chrome.storage.local.get('leads');
  allLeads = leads.slice().reverse(); // Data terbaru di atas
  render();
}

function toCsvValue(v) {
  const s = String(v ?? '');
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

function exportCsv() {
  if (currentFilteredLeads.length === 0) {
    alert('Tidak ada data yang tampil untuk di-export.');
    return;
  }
  
  const rows = [
    ['Nama Bisnis', 'Rating', 'Ulasan', 'Kategori', 'Alamat', 'Telepon', 'Website', 'Status Website', 'Maps URL', 'Tanggal Diambil'],
    ...currentFilteredLeads.map((l) => [
      l.name,
      l.rating || '',
      l.reviewCount || '',
      l.category || '',
      l.address || '',
      l.phone || '',
      l.website || '',
      l.hasWebsite ? 'Ada' : 'Belum Ada',
      l.mapsUrl || '',
      l.scrapedAt,
    ]),
  ];
  const csv = rows.map((r) => r.map(toCsvValue).join(',')).join('\n');
  const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `gmaps-leads-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function exportJson() {
  if (currentFilteredLeads.length === 0) {
    alert('Tidak ada data yang tampil untuk di-export.');
    return;
  }
  const json = JSON.stringify(currentFilteredLeads, null, 2);
  const blob = new Blob([json], { type: 'application/json;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `gmaps-leads-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// 1-Click Sync ke Dashboard Web lokal (http://localhost:3000/api/import)
async function syncToDashboard() {
  if (currentFilteredLeads.length === 0) {
    alert('Tidak ada data yang tampil untuk dikirim ke Dashboard.');
    return;
  }

  syncStatus.style.display = 'block';
  syncStatus.style.background = '#eff6ff';
  syncStatus.style.color = '#1d4ed8';
  syncStatus.textContent = 'Mengirim data ke Dashboard (http://localhost:3000)...';

  try {
    const res = await fetch('http://localhost:3000/api/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ data: currentFilteredLeads }),
    });

    const result = await res.json();
    if (result.success) {
      syncStatus.style.background = '#ecfdf5';
      syncStatus.style.color = '#047857';
      syncStatus.textContent = `✅ Berhasil kirim ${result.inserted} data baru ke Web Dashboard!`;
    } else {
      syncStatus.style.background = '#fef2f2';
      syncStatus.style.color = '#b91c1c';
      syncStatus.textContent = `❌ Gagal: ${result.error || 'Terjadi kesalahan'}`;
    }
  } catch (err) {
    syncStatus.style.background = '#fef2f2';
    syncStatus.style.color = '#b91c1c';
    syncStatus.textContent = `❌ Gagal menghubungi Dashboard di http://localhost:3000. Pastikan server dev ("npm run dev") sudah dijalankan.`;
  }

  setTimeout(() => {
    syncStatus.style.display = 'none';
  }, 6000);
}

searchInput.addEventListener('input', render);
onlyNoWebsite.addEventListener('change', render);
exportCsvBtn.addEventListener('click', exportCsv);
exportJsonBtn.addEventListener('click', exportJson);
syncDashboardBtn.addEventListener('click', syncToDashboard);

clearBtn.addEventListener('click', async () => {
  if (!confirm('Yakin mau menghapus semua data yang sudah tersimpan?')) return;
  await chrome.storage.local.set({ leads: [] });
  loadLeads();
});

addManualBtn.addEventListener('click', () => {
  manualForm.hidden = !manualForm.hidden;
});

mCancelBtn.addEventListener('click', () => {
  manualForm.hidden = true;
  [mName, mCategory, mRating, mReviews, mAddress, mPhone, mWebsite, mMapsUrl].forEach((el) => (el.value = ''));
});

mSaveBtn.addEventListener('click', async () => {
  const name = mName.value.trim();
  if (!name) {
    alert('Nama bisnis wajib diisi.');
    return;
  }
  const website = mWebsite.value.trim();
  const newLead = {
    name,
    category: mCategory.value.trim(),
    rating: mRating.value.trim(),
    reviewCount: mReviews.value.trim(),
    address: mAddress.value.trim(),
    phone: mPhone.value.trim(),
    website,
    hasWebsite: !!website,
    mapsUrl: mMapsUrl.value.trim(),
    scrapedAt: new Date().toISOString(),
  };
  const { leads = [] } = await chrome.storage.local.get('leads');
  leads.push(newLead);
  await chrome.storage.local.set({ leads });

  [mName, mCategory, mRating, mReviews, mAddress, mPhone, mWebsite, mMapsUrl].forEach((el) => (el.value = ''));
  manualForm.hidden = true;
  loadLeads();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.leads) {
    loadLeads();
  }
});

loadLeads();
